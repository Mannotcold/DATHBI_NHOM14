create database _Source
go
use  _Source
GO
CREATE TABLE Lop_source (
    MaLop varchar(10) PRIMARY KEY,
    TenLop NVARCHAR(50),
    createdDate DATETIME,
    updatedDate DATETIME
);

CREATE TABLE Sinhvien_source (
    MaSV VARCHAR(10) PRIMARY KEY,
    HoTen NVARCHAR(50),
    MaLop NVARCHAR(50),-- FOREIGN KEY REFERENCES Lop(malop),
    createdDate DATETIME,
    updatedDate DATETIME
);
INSERT INTO Lop_source (malop, tenlop, createdDate, updatedDate)
VALUES 
('1A', 'Lop 1A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('2A', 'Lop 2A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('3A', 'Lop 3A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('4A', 'Lop 4A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('5A', 'Lop 5A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('1B', 'Lop 1B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('2B', 'Lop 2B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('3B', 'Lop 3B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('4B', 'Lop 4B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('5B', 'Lop 5B', '2022-01-01 00:00:00', '2022-01-01 00:00:00');


INSERT INTO sinhvien_source (masv, hoten, malop, createdDate, updatedDate)
VALUES 
('1', 'Nguyen Van A', '1A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('2', 'Nguyen Van B', '2A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('3', 'Nguyen Van C', '3A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('4', 'Nguyen Van D', '4A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('5', 'Nguyen Van E', '5A', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('6', 'Nguyen Van F', '1B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('7', 'Nguyen Van G', '2B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('8', 'Nguyen Van H', '3B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('9', 'Nguyen Van I', '4B', '2022-01-01 00:00:00', '2022-01-01 00:00:00'),
('10', 'Nguyen Van AK', '5B', '2022-01-01 00:00:00', '2022-01-01 00:00:00');
-----------------------
create database _Stage
GO
USE _Stage
GO

--------------------------------
create database _Metadata
GO
USE _Metadata
GO
create table data_flow(
id int not null identity(1,1),
table_name varchar(30),
lset datetime null,
cet datetime null,
)
INSERT INTO data_flow VALUES
('SinhVien_stage','2015-01-01 00:00:00','2015-01-01 00:00:00'),
('Lop_stage','2015-01-01 00:00:00','2015-01-01 00:00:00'),
('SinhVien_NDS','2015-01-01 00:00:00','2015-01-01 00:00:00'),
('Lop_NDS','2015-01-01 00:00:00','2015-01-01 00:00:00');
-----------------------
create database _NDS;



